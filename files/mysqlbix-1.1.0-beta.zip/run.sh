java -Duser.language=en -Duser.country=US -Dlog4j.configuration=./conf/log4j.properties -jar mysqlbix-1.1.0.jar  ./conf/config.props &
